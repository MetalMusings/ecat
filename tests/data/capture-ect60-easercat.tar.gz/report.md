# EtherCAT report, 2026-11-14 08:00:14

Written by EtherCAT Setup (ecatsetup --report). It holds the configuration, the INI lines about EtherCAT and the joints, a diagnosis of the bus and the ecat component's event log. Look it through before posting it.

## Versions

- linuxcnc-ecat 0.11+git20261112.16e5a33b~debian13
- linuxcnc-ethercat-uspace 1.1+git20261110.6029235a~debian13
- linuxcnc-uspace 1:2.9.4-2
- kernel 6.12.69+deb13-rt-amd64 (PREEMPT_RT)
- system Debian GNU/Linux 13 (trixie)
- ecatsetup /home/debian/src/ecat/ecatsetup

## Configuration (none given)


## Bus

```
Slave 0: ECT60V202(COE)
  State: PREOP (not OP)
  Port 0: link; since power-on: rx 2, phy 255+, lost 255+
    Note: phy and lost at its limit (255+): it cannot show whether the fault is still there. Write to the counter's register (0x0300 for rx and phy errors, 0x0310 for lost links) or power the slave off, then run this again
  Port 1: link; since power-on: phy 255+, lost 1
    Note: phy at its limit (255+): it cannot show whether the fault is still there. Write to the counter's register (0x0300 for rx and phy errors, 0x0310 for lost links) or power the slave off, then run this again
  CiA 402: Switch on disabled (status word 0x1A50), mode CSP, requested none
    -> waiting for Shutdown (control word 0x06): enable is not set, or a fault was just reset

Slave 1: ECT60V202(COE)
  State: PREOP (not OP)
  Port 0: link; since power-on: phy 65, lost 1
  Port 1: link; since power-on: phy 111, lost 1
  CiA 402: Switch on disabled (status word 0x1A50), mode CSP, requested none
    -> waiting for Shutdown (control word 0x06): enable is not set, or a fault was just reset

Slave 2: ECT60V202(COE)
  State: PREOP (not OP)
  Port 0: link
  Port 1: link
  CiA 402: Switch on disabled (status word 0x1A50), mode CSP, requested none
    -> waiting for Shutdown (control word 0x06): enable is not set, or a fault was just reset

Slave 3: MetalMusings EaserCAT 7000
  State: PREOP (not OP)
  Port 0: link; since power-on: phy 255+, lost 1
    Note: phy at its limit (255+): it cannot show whether the fault is still there. Write to the counter's register (0x0300 for rx and phy errors, 0x0310 for lost links) or power the slave off, then run this again

Note: the link was lost 1 time since power-on between slave 0 port 1 and slave 1 port 0: that cable was disconnected, loose or the slave behind it lost power (the counters are not cleared; a cable pulled on purpose counts too)
```
4 problem(s) found

## Event log, this run (or the last)

```
Event log /dev/shm/ecat-events: ecat stopped at 2026-11-13 20:09:40.329, ethercat.yaml, servo period 500 us
2026-11-13 20:09:40.329       ecat loaded, 4 slaves in the file
2026-11-13 20:09:44.455       master activated, servo period 500 us
2026-11-13 20:09:44.455       slaves' states: PREOP (was none)
2026-11-13 20:09:44.455       4 slaves respond (was 0)
2026-11-13 20:09:44.455       slave 0: PREOP (was unknown)
2026-11-13 20:09:44.455       slave 1: PREOP (was unknown)
2026-11-13 20:09:44.455       slave 2: PREOP (was unknown)
2026-11-13 20:09:44.455       slave 3: PREOP (was unknown)
2026-11-13 20:09:44.693       working counter incomplete (was zero)
2026-11-13 20:09:44.794       working counter complete (was incomplete)
2026-11-13 20:09:45.456       slaves' states: OP (was PREOP)
2026-11-13 20:09:45.456       slave 0: OP (was PREOP)
2026-11-13 20:09:45.456       slave 0 operational
2026-11-13 20:09:45.456       slave 1: OP (was PREOP)
2026-11-13 20:09:45.456       slave 1 operational
2026-11-13 20:09:45.456       slave 2: OP (was PREOP)
2026-11-13 20:09:45.456       slave 2 operational
2026-11-13 20:09:45.456       slave 3: OP (was PREOP)
2026-11-13 20:09:45.456       slave 3 operational
2026-11-13 20:09:47.455       SYNC0 shift 268 us, turn-around 2 cycles
2026-11-13 20:10:46.542 WARN  servo thread late: 633 us since its last write
2026-11-13 20:10:46.547 WARN  stop guard: the servo thread stopped; taking the slaves to PREOP
2026-11-13 20:10:46.590       ecat unloading
2026-11-13 20:10:46.609       stop guard: done, outputs zero, slaves in PREOP
```

## Event log, the run before

```
Event log /dev/shm/ecat-events.prev: ecat stopped at 2026-11-13 09:05:18.456, ethercat.yaml, servo period 1000 us
2026-11-13 09:05:18.456       ecat loaded, 4 slaves in the file
2026-11-13 09:05:22.598       master activated, servo period 1000 us
2026-11-13 09:05:22.599       slaves' states: PREOP (was none)
2026-11-13 09:05:22.599       4 slaves respond (was 0)
2026-11-13 09:05:22.599       slave 0: PREOP (was unknown)
2026-11-13 09:05:22.599       slave 1: PREOP (was unknown)
2026-11-13 09:05:22.599       slave 2: PREOP (was unknown)
2026-11-13 09:05:22.599       slave 3: PREOP (was unknown)
2026-11-13 09:05:22.776       working counter incomplete (was zero)
2026-11-13 09:05:22.842       working counter complete (was incomplete)
2026-11-13 09:05:23.600       slaves' states: OP (was PREOP)
2026-11-13 09:05:23.600       slave 0: OP (was PREOP)
2026-11-13 09:05:23.600       slave 0 operational
2026-11-13 09:05:23.600       slave 1: OP (was PREOP)
2026-11-13 09:05:23.600       slave 1 operational
2026-11-13 09:05:23.600       slave 2: OP (was PREOP)
2026-11-13 09:05:23.600       slave 2 operational
2026-11-13 09:05:23.600       slave 3: OP (was PREOP)
2026-11-13 09:05:23.600       slave 3 operational
2026-11-13 09:05:25.599       SYNC0 shift 519 us, turn-around 2 cycles
2026-11-13 09:15:24.582 WARN  servo thread late: 1467 us since its last write
2026-11-13 09:15:24.591 WARN  stop guard: the servo thread stopped; taking the slaves to PREOP
2026-11-13 09:15:24.613       ecat unloading
2026-11-13 09:15:24.637       stop guard: done, outputs zero, slaves in PREOP
```
