# EtherCAT report, 2026-11-14 08:17:53

Written by EtherCAT Setup (ecatsetup --report). It holds the configuration, the INI lines about EtherCAT and the joints, a diagnosis of the bus and the ecat component's event log. Look it through before posting it.

## Versions

- linuxcnc-ecat 0.11+git20261112.16e5a33b~debian13
- linuxcnc-ethercat-uspace 1.1+git20261110.6029235a~debian13
- linuxcnc-uspace 1:2.9.4-2
- kernel 6.12.69+deb13-rt-amd64 (PREEMPT_RT)
- system Debian GNU/Linux 13 (trixie)
- ecatsetup /home/debian/src/ecat/ecatsetup

## Configuration /tmp/claude-1000/-home-debian-src-ecat/729cb256-7808-42b7-8486-47e7d074e81b/scratchpad/op/ethercat.yaml

```
# ecat configuration, written by EtherCAT Setup.
# Read by the ecat HAL component: loadrt ecat config=<this file>
# Format: https://github.com/MetalMusings/ecat/blob/main/docs/config-format.md
# The program rewrites this file; comments added by hand are not kept.
ecat: 1
master:
  interface: enp2s0
  transport: raw
  dc:
    ref-clock-sync-cycles: 1000
    servo-thread-follows-ref-clock: true
    sync0-shift-ns: 300000
slaves:
- position: 0
  name: lcec.0.X
  device: ECT60V202(COE)
  identity: {vendor: '0x00000A88', product: '0x0A880002', revision: '0x00000202'}
  profile: cia402
  configure-pdos: true
  process-data:
    outputs:
    - pdo: '0x1600'
      sm: 2
      entries:
      - {object: '0x6040:00', bits: 16, type: UINT, use: profile}
      - {object: '0x6060:00', bits: 8, type: SINT, use: profile}
      - {object: '0x607A:00', bits: 32, type: DINT, use: profile}
      - {object: '0x60FF:00', bits: 32, type: DINT, use: profile}
    inputs:
    - pdo: '0x1A00'
      sm: 3
      entries:
      - {object: '0x6041:00', bits: 16, type: UINT, use: profile}
      - {object: '0x6061:00', bits: 8, type: SINT, use: profile}
      - {object: '0x6064:00', bits: 32, type: DINT, use: profile}
      - {object: '0x606C:00', bits: 32, type: DINT, use: profile}
      - {object: '0x6077:00', bits: 32, type: DINT, pin: actual-torque, hal-type: s32}
  dc:
    assign-activate: '0x0300'
    sync0-cycles: 1
    sync0-shift-ns: 0
  settings:
  - {object: '0x2000:00', name: Peak Current, type: UINT, value: 4000}
  - {object: '0x2003:00', name: Idle Current Percentage, type: UINT, value: 100}
  - {object: '0x2011:00', name: Control mode, type: UINT, value: 1}
  - {object: '0x2023:01', name: 'Position loop parameters: PosLoop_Kp', type: UINT, value: 4000}
  cia402:
    mode: csp
- position: 1
  name: lcec.0.Y
  device: ECT60V202(COE)
  identity: {vendor: '0x00000A88', product: '0x0A880002', revision: '0x00000202'}
  profile: cia402
  configure-pdos: true
  process-data:
    outputs:
    - pdo: '0x1600'
      sm: 2
      entries:
      - {object: '0x6040:00', bits: 16, type: UINT, use: profile}
      - {object: '0x6060:00', bits: 8, type: SINT, use: profile}
      - {object: '0x607A:00', bits: 32, type: DINT, use: profile}
      - {object: '0x60FF:00', bits: 32, type: DINT, use: profile}
    inputs:
    - pdo: '0x1A00'
      sm: 3
      entries:
      - {object: '0x6041:00', bits: 16, type: UINT, use: profile}
      - {object: '0x6061:00', bits: 8, type: SINT, use: profile}
      - {object: '0x6064:00', bits: 32, type: DINT, use: profile}
      - {object: '0x606C:00', bits: 32, type: DINT, use: profile}
      - {object: '0x6077:00', bits: 32, type: DINT, pin: actual-torque, hal-type: s32}
  dc:
    assign-activate: '0x0300'
    sync0-cycles: 1
    sync0-shift-ns: 0
  settings:
  - {object: '0x2000:00', name: Peak Current, type: UINT, value: 5000}
  - {object: '0x2003:00', name: Idle Current Percentage, type: UINT, value: 100}
  - {object: '0x200D:00', name: Invert motor direction, type: UINT, value: 1}
  - {object: '0x2011:00', name: Control mode, type: UINT, value: 1}
  - {object: '0x2023:01', name: 'Position loop parameters: PosLoop_Kp', type: UINT, value: 4000}
  cia402:
    mode: csp
- position: 2
  name: lcec.0.Z
  device: ECT60V202(COE)
  identity: {vendor: '0x00000A88', product: '0x0A880002', revision: '0x00000202'}
  profile: cia402
  configure-pdos: true
  process-data:
    outputs:
    - pdo: '0x1600'
      sm: 2
      entries:
      - {object: '0x6040:00', bits: 16, type: UINT, use: profile}
      - {object: '0x6060:00', bits: 8, type: SINT, use: profile}
      - {object: '0x607A:00', bits: 32, type: DINT, use: profile}
      - {object: '0x60FF:00', bits: 32, type: DINT, use: profile}
    inputs:
    - pdo: '0x1A00'
      sm: 3
      entries:
      - {object: '0x6041:00', bits: 16, type: UINT, use: profile}
      - {object: '0x6061:00', bits: 8, type: SINT, use: profile}
      - {object: '0x6064:00', bits: 32, type: DINT, use: profile}
      - {object: '0x606C:00', bits: 32, type: DINT, use: profile}
      - {object: '0x6077:00', bits: 32, type: DINT, pin: actual-torque, hal-type: s32}
  dc:
    assign-activate: '0x0300'
    sync0-cycles: 1
    sync0-shift-ns: 0
  settings:
  - {object: '0x2000:00', name: Peak Current, type: UINT, value: 2232}
  - {object: '0x2003:00', name: Idle Current Percentage, type: UINT, value: 100}
  - {object: '0x200D:00', name: Invert motor direction, type: UINT, value: 1}
  - {object: '0x2011:00', name: Control mode, type: UINT, value: 0}
  cia402:
    mode: csp
- position: 3
  name: lcec.0.E7000
  device: MetalMusings EaserCAT 7000
  identity: {vendor: '0xD0BED1D0', product: '0x00007000', revision: '0x00000002'}
  profile: generic
  configure-pdos: false
  process-data:
    outputs:
    - pdo: '0x1600'
      sm: 2
      entries:
      - {object: '0x7000:00', bits: 8, type: USINT, split: [out-1, out-2, ActivateRelay, out-4]}
    - pdo: '0x1601'
      sm: 2
      entries:
      - {object: '0x7001:01', bits: 32, type: REAL, pin: voltageScale-1, hal-type: float}
      - {object: '0x7001:02', bits: 32, type: REAL, pin: voltageOffset-1, hal-type: float}
      - {object: '0x7001:03', bits: 32, type: REAL, pin: LowPassFilterThresholdVoltage-1, hal-type: float}
      - {object: '0x7001:04', bits: 8, type: USINT, split: [EnableOhmicSensing-1]}
      - {object: '0x7001:05', bits: 32, type: REAL, pin: OhmicSensingVoltageLimit-1, hal-type: float}
      - {object: '0x7001:06', bits: 32, type: REAL, pin: OhmicSensingVoltageDrop-1, hal-type: float}
    - pdo: '0x1602'
      sm: 2
      entries:
      - {object: '0x7002:01', bits: 32, type: REAL, pin: voltageScale-2, hal-type: float}
      - {object: '0x7002:02', bits: 32, type: REAL, pin: voltageOffset-2, hal-type: float}
      - {object: '0x7002:03', bits: 32, type: REAL, pin: LowPassFilterThresholdVoltage-2, hal-type: float}
      - {object: '0x7002:04', bits: 8, type: USINT, split: [EnableOhmicSensing-2]}
      - {object: '0x7002:05', bits: 32, type: REAL, pin: OhmicSensingVoltageLimit-2, hal-type: float}
      - {object: '0x7002:06', bits: 32, type: REAL, pin: OhmicSensingVoltageDrop-2, hal-type: float}
    inputs:
    - pdo: '0x1A00'
      sm: 3
      entries:
      - {object: '0x6000:00', bits: 32, type: DINT, split: [in-1, in-2, in-3, in-4, in-5, in-6, in-7,
          in-8, in-9, in-10, in-11, in-12]}
    - pdo: '0x1A01'
      sm: 3
      entries:
      - {object: '0x6001:01', bits: 32, type: DINT, pin: rawData-1, hal-type: s32}
      - {object: '0x6001:02', bits: 32, type: REAL, pin: calculatedVoltage-1, hal-type: float}
      - {object: '0x6001:03', bits: 32, type: UDINT, pin: status-1, hal-type: u32}
      - {object: '0x6001:04', bits: 32, type: REAL, pin: LowPassFilteredVoltage-1, hal-type: float}
      - {object: '0x6001:05', bits: 8, type: USINT, split: [OhmicSensingSensed-1]}
    - pdo: '0x1A02'
      sm: 3
      entries:
      - {object: '0x6002:01', bits: 32, type: DINT, pin: rawData-2, hal-type: s32}
      - {object: '0x6002:02', bits: 32, type: REAL, pin: calculatedVoltage-2, hal-type: float}
      - {object: '0x6002:03', bits: 32, type: UDINT, pin: status-2, hal-type: u32}
      - {object: '0x6002:04', bits: 32, type: REAL, pin: LowPassFilteredVoltage-2, hal-type: float}
      - {object: '0x6002:05', bits: 8, type: USINT, split: [OhmicSensingSensed-2]}
  settings:
  - {object: '0x2000:01', name: 'Settings_Unit1: I2C_devicetype', type: USINT, value: 2}
  - {object: '0x2000:02', name: 'Settings_Unit1: I2C_address', type: USINT, value: 72}
  - {object: '0x2000:03', name: 'Settings_Unit1: LowpassFilterPoleFrequency', type: UDINT, value: 10}
  - {object: '0x2000:04', name: 'Settings_Unit1: OhmicSensingSetupTime', type: UINT, value: 100}
  - {object: '0x2000:05', name: 'Settings_Unit1: OhmicSensingPulseLength', type: UINT, value: 5}
  - {object: '0x2001:01', name: 'Settings_Unit2: I2C_devicetype', type: USINT, value: 2}
  - {object: '0x2001:02', name: 'Settings_Unit2: I2C_address', type: USINT, value: 73}
  - {object: '0x2001:03', name: 'Settings_Unit2: LowpassFilterPoleFrequency', type: UDINT, value: 10}
  - {object: '0x2001:04', name: 'Settings_Unit2: OhmicSensingSetupTime', type: UINT, value: 50}
  - {object: '0x2001:05', name: 'Settings_Unit2: OhmicSensingPulseLength', type: UINT, value: 5}
```

Check: no errors
Interface enp2s0: driver igc, xdp-native yes

## Bus

```
Slave 0: ECT60V202(COE)
  State: OP
  Port 0: link; since power-on: rx 2, phy 255+, lost 255+
    Note: phy and lost at its limit (255+): it cannot show whether the fault is still there. Write to the counter's register (0x0300 for rx and phy errors, 0x0310 for lost links) or power the slave off, then run this again
  Port 1: link; since power-on: phy 255+, lost 1
    Note: phy at its limit (255+): it cannot show whether the fault is still there. Write to the counter's register (0x0300 for rx and phy errors, 0x0310 for lost links) or power the slave off, then run this again
  CiA 402: Ready to switch on (status word 0x0A31), mode CSP
    -> waiting for Switch on (control word 0x07): enable is not set

Slave 1: ECT60V202(COE)
  State: OP
  Port 0: link; since power-on: phy 65, lost 1
  Port 1: link; since power-on: phy 111, lost 1
  CiA 402: Ready to switch on (status word 0x0A31), mode CSP
    -> waiting for Switch on (control word 0x07): enable is not set

Slave 2: ECT60V202(COE)
  State: OP
  Port 0: link
  Port 1: link
  CiA 402: Ready to switch on (status word 0x0A31), mode CSP
    -> waiting for Switch on (control word 0x07): enable is not set

Slave 3: MetalMusings EaserCAT 7000
  State: OP
  Port 0: link; since power-on: phy 255+, lost 1
    Note: phy at its limit (255+): it cannot show whether the fault is still there. Write to the counter's register (0x0300 for rx and phy errors, 0x0310 for lost links) or power the slave off, then run this again

Note: the link was lost 1 time since power-on between slave 0 port 1 and slave 1 port 0: that cable was disconnected, loose or the slave behind it lost power (the counters are not cleared; a cable pulled on purpose counts too)
```
No problems found

## Event log, this run (or the last)

```
Event log /dev/shm/ecat-events: ecat running at 2026-11-14 08:16:33.342, /tmp/claude-1000/-home-debian-src-ecat/729cb256-7808-42b7-8486-47e7d074e81b/scratchpad/op/ethercat.yaml, servo period 1000 us
2026-11-14 08:16:33.342       ecat loaded, 4 slaves in the file
2026-11-14 08:16:35.174       master activated, servo period 1000 us
2026-11-14 08:16:35.174       slaves' states: PREOP (was none)
2026-11-14 08:16:35.174       4 slaves respond (was 0)
2026-11-14 08:16:35.174       slave 0 (lcec.0.X): PREOP (was unknown)
2026-11-14 08:16:35.174       slave 1 (lcec.0.Y): PREOP (was unknown)
2026-11-14 08:16:35.174       slave 2 (lcec.0.Z): PREOP (was unknown)
2026-11-14 08:16:35.174       slave 3 (lcec.0.E7000): PREOP (was unknown)
2026-11-14 08:16:35.412       working counter incomplete (was zero)
2026-11-14 08:16:35.525       working counter complete (was incomplete)
2026-11-14 08:16:36.175       slaves' states: OP (was PREOP)
2026-11-14 08:16:36.175       slave 0 (lcec.0.X): OP (was PREOP)
2026-11-14 08:16:36.175       slave 0 (lcec.0.X) operational
2026-11-14 08:16:36.175       slave 1 (lcec.0.Y): OP (was PREOP)
2026-11-14 08:16:36.175       slave 1 (lcec.0.Y) operational
2026-11-14 08:16:36.175       slave 2 (lcec.0.Z): OP (was PREOP)
2026-11-14 08:16:36.175       slave 2 (lcec.0.Z) operational
2026-11-14 08:16:36.175       slave 3 (lcec.0.E7000): OP (was PREOP)
2026-11-14 08:16:36.175       slave 3 (lcec.0.E7000) operational
```

## Event log, the run before

```
Event log /dev/shm/ecat-events.prev: ecat stopped at 2026-11-14 08:15:22.552, /tmp/claude-1000/-home-debian-src-ecat/729cb256-7808-42b7-8486-47e7d074e81b/scratchpad/op/ethercat.yaml, servo period 1000 us
2026-11-14 08:15:22.552       ecat loaded, 4 slaves in the file
2026-11-14 08:15:24.379       ecat unloading
2026-11-14 08:15:24.384       master activated, servo period 1000 us
```
